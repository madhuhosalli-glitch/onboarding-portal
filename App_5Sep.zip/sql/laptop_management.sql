-- Laptop Management tables and policies

create table if not exists laptops (
  id uuid primary key default gen_random_uuid(),
  asset_tag text unique not null,
  serial_number text,
  brand text,
  model text,
  processor text,
  ram text,
  storage text,
  operating_system text,
  purchase_date date,
  warranty_expiry date,
  status text default 'Active',
  condition_notes text,
  current_user_id uuid,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists laptop_transfers (
  id uuid primary key default gen_random_uuid(),
  laptop_id uuid references laptops(id) on delete cascade,
  from_user_id uuid,
  to_user_id uuid,
  transfer_date timestamptz default now(),
  remarks text,
  created_by uuid,
  created_at timestamptz default now()
);

create table if not exists laptop_complaints (
  id uuid primary key default gen_random_uuid(),
  laptop_id uuid references laptops(id) on delete set null,
  user_id uuid not null,
  subject text not null,
  description text not null,
  priority text default 'Medium',
  status text default 'Pending',
  admin_notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  resolved_at timestamptz
);

alter table laptops enable row level security;
alter table laptop_transfers enable row level security;
alter table laptop_complaints enable row level security;

-- helper expression repeated: admin/partner profile for logged-in user

drop policy if exists "Admins can manage laptops" on laptops;
drop policy if exists "Assigned users can view own laptops" on laptops;
drop policy if exists "Admins can view transfers" on laptop_transfers;
drop policy if exists "Admins can insert transfers" on laptop_transfers;
drop policy if exists "Users can view own complaints" on laptop_complaints;
drop policy if exists "Users can insert own complaints" on laptop_complaints;
drop policy if exists "Admins can view all complaints" on laptop_complaints;
drop policy if exists "Admins can update complaints" on laptop_complaints;

create policy "Admins can manage laptops"
on laptops
for all
to authenticated
using (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
)
with check (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
);

create policy "Assigned users can view own laptops"
on laptops
for select
to authenticated
using (current_user_id = auth.uid());

create policy "Admins can view transfers"
on laptop_transfers
for select
to authenticated
using (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
);

create policy "Admins can insert transfers"
on laptop_transfers
for insert
to authenticated
with check (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
);

create policy "Users can view own complaints"
on laptop_complaints
for select
to authenticated
using (user_id = auth.uid());

create policy "Users can insert own complaints"
on laptop_complaints
for insert
to authenticated
with check (user_id = auth.uid());

create policy "Admins can view all complaints"
on laptop_complaints
for select
to authenticated
using (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
);

create policy "Admins can update complaints"
on laptop_complaints
for update
to authenticated
using (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
)
with check (
  exists (
    select 1 from employee_profiles ep
    where ep.user_id = auth.uid()
      and (lower(coalesce(ep.role, '')) like '%admin%' or lower(coalesce(ep.role, '')) like '%partner%')
  )
);
