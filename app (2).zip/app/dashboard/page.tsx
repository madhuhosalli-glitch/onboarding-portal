"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabase";

export default function DashboardPage() {
  const router = useRouter();

  const [userId, setUserId] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [profile, setProfile] = useState<any>(null);
  const [modules, setModules] = useState<any[]>([]);
  const [progress, setProgress] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [fullName, setFullName] = useState("");
  const [personalEmail, setPersonalEmail] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  const [sroNumber, setSroNumber] = useState("");
  const [foundationMarks, setFoundationMarks] = useState("");
  const [ipccGroup1Marks, setIpccGroup1Marks] = useState("");
  const [ipccGroup2Marks, setIpccGroup2Marks] = useState("");

  const role = (profile?.role || "").toLowerCase();
  const isArticle = role.includes("article");
  const isAdminOrPartner = role.includes("admin") || role.includes("partner");
  const passwordNotChanged = profile && profile.password_changed !== true;

  const articleProfileIncomplete =
    isArticle &&
    (!profile?.personal_email ||
      !profile?.mobile_number ||
      !profile?.sro_number ||
      !profile?.foundation_marks ||
      !profile?.ipcc_group1_marks ||
      !profile?.ipcc_group2_marks);

  const normalProfileIncomplete =
    !isArticle && (!profile?.personal_email || !profile?.mobile_number);

  const needsFirstLoginForm = articleProfileIncomplete || normalProfileIncomplete;

  useEffect(() => {
    const loadDashboard = async () => {
      const { data: userData } = await supabase.auth.getUser();

      if (!userData.user) {
        router.push("/login");
        return;
      }

      const uid = userData.user.id;
      setUserId(uid);
      setUserEmail(userData.user.email || "");

      const { data: profileData } = await supabase
        .from("employee_profiles")
        .select("*")
        .eq("user_id", uid)
        .single();

      setProfile(profileData);
      setFullName(profileData?.full_name || "");
      setPersonalEmail(profileData?.personal_email || "");
      setMobileNumber(profileData?.mobile_number || "");
      setSroNumber(profileData?.sro_number || "");
      setFoundationMarks(profileData?.foundation_marks || "");
      setIpccGroup1Marks(profileData?.ipcc_group1_marks || "");
      setIpccGroup2Marks(profileData?.ipcc_group2_marks || "");

      const { data: modulesData } = await supabase
        .from("training_modules")
        .select("*")
        .order("display_order", { ascending: true });

      const { data: progressData } = await supabase
        .from("training_progress")
        .select("*")
        .eq("user_id", uid);

      setModules(modulesData || []);
      setProgress(progressData || []);
      setLoading(false);
    };

    loadDashboard();
  }, [router]);

  const handleChangePassword = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaving(true);
    setMessage("");

    if (newPassword.length < 8) {
      setMessage("Password must be at least 8 characters.");
      setSaving(false);
      return;
    }

    if (newPassword !== confirmPassword) {
      setMessage("Passwords do not match.");
      setSaving(false);
      return;
    }

    const { error: passwordError } = await supabase.auth.updateUser({
      password: newPassword,
    });

    if (passwordError) {
      setMessage("Password change failed: " + passwordError.message);
      setSaving(false);
      return;
    }

    const { error: profileError } = await supabase
      .from("employee_profiles")
      .update({ password_changed: true })
      .eq("user_id", userId);

    if (profileError) {
      setMessage("Password changed, but profile flag failed: " + profileError.message);
      setSaving(false);
      return;
    }

    setProfile((prev: any) => ({ ...prev, password_changed: true }));
    setNewPassword("");
    setConfirmPassword("");
    setMessage("Password changed successfully. Please complete your profile.");
    setSaving(false);
  };

  const handleSaveProfile = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaving(true);
    setMessage("");

    const updateData: any = {
      user_id: userId,
      full_name: fullName,
      personal_email: personalEmail,
      mobile_number: mobileNumber,
    };

    if (isArticle) {
      updateData.sro_number = sroNumber;
      updateData.foundation_marks = foundationMarks;
      updateData.ipcc_group1_marks = ipccGroup1Marks;
      updateData.ipcc_group2_marks = ipccGroup2Marks;
    }

    const { error } = await supabase.from("employee_profiles").upsert(updateData, {
      onConflict: "user_id",
    });

    if (error) {
      setMessage("Error saving profile: " + error.message);
      setSaving(false);
      return;
    }

    const { data: updatedProfile } = await supabase
      .from("employee_profiles")
      .select("*")
      .eq("user_id", userId)
      .single();

    setProfile(updatedProfile);
    setMessage("Profile saved successfully.");
    setSaving(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/login");
  };

  const completedTraining = progress.filter((p) => p.status === "Passed").length;
  const pendingTraining = Math.max(modules.length - completedTraining, 0);

  if (loading) {
    return <div className="p-10 text-xl font-bold text-slate-900">Loading BVC Office Portal...</div>;
  }

  if (passwordNotChanged) {
    return (
      <div className="min-h-screen bg-slate-100 p-6">
        <div className="mx-auto max-w-3xl space-y-6">
          <div className="rounded-3xl bg-gradient-to-r from-red-700 to-slate-900 p-8 text-white shadow-2xl">
            <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl font-extrabold">Change Default Password</h1>
                <p className="mt-2 text-red-100">For security, please change your password before accessing the Office Portal.</p>
                <p className="mt-2 text-sm text-red-200">Logged in as: {userEmail}</p>
              </div>
              <button onClick={handleLogout} className="rounded-2xl bg-white px-6 py-3 text-sm font-bold text-red-700 hover:bg-red-50">Logout</button>
            </div>
          </div>

          <div className="rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-200">
            <form onSubmit={handleChangePassword} className="grid gap-5">
              <Input label="New Password" type="password" value={newPassword} onChange={setNewPassword} />
              <Input label="Confirm New Password" type="password" value={confirmPassword} onChange={setConfirmPassword} />
              <button type="submit" disabled={saving} className="rounded-2xl bg-red-700 px-7 py-3 font-bold text-white hover:bg-red-800 disabled:opacity-70">
                {saving ? "Changing..." : "Change Password"}
              </button>
              {message && <p className="text-sm font-bold text-red-700">{message}</p>}
            </form>
          </div>
        </div>
      </div>
    );
  }

  if (needsFirstLoginForm) {
    return (
      <div className="min-h-screen bg-slate-100 p-6">
        <div className="mx-auto max-w-5xl space-y-6">
          <div className="rounded-3xl bg-gradient-to-r from-blue-900 to-slate-900 p-8 text-white shadow-2xl">
            <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl font-extrabold">Welcome, {fullName || "Team Member"}</h1>
                <p className="mt-2 text-blue-100">Please complete your basic profile before accessing the Office Portal.</p>
                <p className="mt-2 text-sm text-blue-200">Logged in as: {userEmail}</p>
              </div>
              <button onClick={handleLogout} className="rounded-2xl bg-red-600 px-6 py-3 text-sm font-bold text-white hover:bg-red-700">Logout</button>
            </div>
          </div>

          <div className="rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-200">
            <h2 className="text-2xl font-bold text-slate-950">First Login Details</h2>
            <p className="mt-2 text-slate-600">Complete this once to activate your Office Portal profile.</p>

            <form onSubmit={handleSaveProfile} className="mt-8 grid gap-5 md:grid-cols-2">
              <Input label="Full Name" value={fullName} onChange={setFullName} />
              <Input label="Personal Email ID" type="email" value={personalEmail} onChange={setPersonalEmail} />
              <Input label="Mobile Number" value={mobileNumber} onChange={setMobileNumber} />
              <Input label="Role" value={profile?.role || "-"} onChange={() => {}} disabled />

              {isArticle && (
                <>
                  <Input label="SRO Number" value={sroNumber} onChange={setSroNumber} />
                  <Input label="Foundation Marks" value={foundationMarks} onChange={setFoundationMarks} />
                  <Input label="IPCC / Inter Group 1 Marks" value={ipccGroup1Marks} onChange={setIpccGroup1Marks} />
                  <Input label="IPCC / Inter Group 2 Marks" value={ipccGroup2Marks} onChange={setIpccGroup2Marks} />
                </>
              )}

              <div className="md:col-span-2 flex flex-wrap items-center gap-4">
                <button type="submit" disabled={saving} className="rounded-2xl bg-blue-700 px-7 py-3 font-bold text-white hover:bg-blue-800 disabled:opacity-70">
                  {saving ? "Saving..." : "Save and Continue"}
                </button>
                {message && <p className="text-sm font-bold text-red-700">{message}</p>}
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="rounded-3xl bg-gradient-to-r from-blue-900 via-slate-900 to-purple-900 p-8 text-white shadow-2xl">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-blue-200">BVC Office Portal</p>
              <h1 className="mt-3 text-4xl font-extrabold tracking-tight">Welcome, {profile?.full_name || "Team Member"}</h1>
              <p className="mt-3 text-lg text-blue-100">Training • SOPs • Office Operations • IT Assets • Employee Services</p>
              <div className="mt-5 flex flex-wrap gap-3">
                <InfoPill label={`Role: ${profile?.role || "-"}`} />
                {isArticle && <InfoPill label={`SRO No: ${profile?.sro_number || "-"}`} />}
              </div>
            </div>
            <button onClick={handleLogout} className="rounded-2xl bg-red-600 px-6 py-3 text-sm font-bold text-white shadow-lg transition hover:scale-105 hover:bg-red-700">Logout</button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <SummaryCard title="Training Modules" value={modules.length} color="bg-slate-900" />
          <SummaryCard title="Training Completed" value={completedTraining} color="bg-green-700" />
          <SummaryCard title="Training Pending" value={pendingTraining} color="bg-yellow-600" />
          <SummaryCard title="Role" value={profile?.role || "-"} color="bg-indigo-700" />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <ModuleCard
            title="Onboarding Module"
            description="Training modules, quizzes, SOP library and learning progress."
            color="from-blue-700 to-slate-900"
            items={["Training Modules", "SOP Library", "Profile"]}
            actions={[
              { label: "Open Training", href: "/training" },
              { label: "Open SOP Library", href: "/sops" },
            ]}
            router={router}
          />

          <ModuleCard
            title="Laptop Management"
            description="Raise laptop complaints, view IT support and manage assigned laptop issues."
            color="from-cyan-700 to-slate-900"
            items={["Laptop Support", "Raise Complaint", "My Laptop"]}
            actions={[{ label: "Open Laptop Support", href: "/laptops" }]}
            router={router}
          />

          {isAdminOrPartner && (
            <ModuleCard
              title="Admin Portal"
              description="Employee database, laptop inventory, SOP compliance and reports."
              color="from-purple-700 to-slate-900"
              items={["Employee Management", "Laptop Admin", "SOP Compliance"]}
              actions={[
                { label: "Open Admin", href: "/admin" },
                { label: "SOP Compliance", href: "/admin/sop-compliance" },
              ]}
              router={router}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function Input({ label, value, onChange, type = "text", disabled = false }: { label: string; value: string; onChange: (value: string) => void; type?: string; disabled?: boolean }) {
  return (
    <div>
      <label className="mb-2 block text-sm font-bold text-slate-800">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        required={!disabled}
        className="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-slate-950 outline-none focus:border-blue-600 focus:bg-white disabled:bg-slate-200 disabled:text-slate-700"
      />
    </div>
  );
}

function InfoPill({ label }: { label: string }) {
  return <div className="rounded-2xl bg-white/10 px-4 py-2 text-sm font-semibold">{label}</div>;
}

function SummaryCard({ title, value, color }: { title: string; value: string | number; color: string }) {
  return (
    <div className={`${color} rounded-2xl p-5 text-white shadow-xl`}>
      <p className="text-sm font-bold text-white/80">{title}</p>
      <p className="mt-2 text-3xl font-extrabold">{value}</p>
    </div>
  );
}

function ModuleCard({ title, description, color, items, actions, router }: { title: string; description: string; color: string; items: string[]; actions: { label: string; href: string }[]; router: any }) {
  return (
    <div className={`rounded-3xl bg-gradient-to-br ${color} p-7 text-white shadow-2xl transition hover:-translate-y-1 hover:shadow-3xl`}>
      <h2 className="text-3xl font-extrabold">{title}</h2>
      <p className="mt-3 min-h-16 text-sm leading-6 text-white/80">{description}</p>
      <div className="mt-5 grid gap-2">
        {items.map((item) => (
          <div key={item} className="rounded-2xl bg-white/10 px-4 py-3 text-sm font-bold ring-1 ring-white/10">{item}</div>
        ))}
      </div>
      <div className="mt-6 flex flex-wrap gap-3">
        {actions.map((action) => (
          <button key={action.href} onClick={() => router.push(action.href)} className="rounded-2xl bg-white px-5 py-3 text-sm font-bold text-slate-900 hover:bg-slate-100">
            {action.label}
          </button>
        ))}
      </div>
    </div>
  );
}
