"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabase";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrorMessage("");
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);

    if (error) {
      setErrorMessage(error.message);
      return;
    }

    router.push("/dashboard");
  };

  return (
    <div className="grid min-h-[calc(100vh-110px)] items-center gap-5 lg:grid-cols-2">
      <section className="hidden lg:block">
        <div className="relative overflow-hidden rounded-[1.75rem] bg-gradient-to-br from-slate-900 via-blue-900 to-blue-700 p-7 text-white shadow-2xl">
          <div className="absolute -right-16 -top-16 h-44 w-44 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -bottom-20 -left-16 h-48 w-48 rounded-full bg-cyan-300/10 blur-3xl" />

          <div className="relative z-10">
            <div className="mb-3 inline-flex rounded-full border border-white/20 bg-white/10 px-4 py-1 text-xs font-semibold backdrop-blur">
              Secure Internal Office Access
            </div>

            <h1 className="max-w-lg text-3xl font-extrabold leading-tight">
              Welcome to BVC Office Portal
            </h1>

            <p className="mt-3 max-w-xl text-sm leading-6 text-blue-100">
              One secure platform for training, SOPs, IT assets, office operations and employee services.
            </p>

            <div className="mt-6 grid gap-3 md:grid-cols-2">
              <FeatureCard
                title="Onboarding & Training"
                text="Complete training modules, quizzes and track progress."
              />
              <FeatureCard
                title="SOP Library"
                text="Access office SOPs, process guides and policies."
              />
              <FeatureCard
                title="IT & Assets"
                text="Manage laptop support, complaints and asset records."
              />
              <FeatureCard
                title="Office Operations"
                text="Submit assigned checklists and compliance tasks."
              />
            </div>
          </div>
        </div>
      </section>

      <section className="flex items-center justify-center">
        <div className="w-full max-w-md rounded-[1.75rem] bg-white p-7 shadow-2xl ring-1 ring-slate-200">
          <div className="mb-6">
            <div className="mb-3 inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-blue-700 ring-1 ring-blue-100">
              Secure Login
            </div>
            <h2 className="text-3xl font-bold tracking-tight text-slate-900">
              Welcome Back
            </h2>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Sign in using your official BVC email address to access the Office Portal.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-semibold text-slate-700">
                Official Email Address
              </label>
              <input
                type="email"
                placeholder="name@bvcglobal.com"
                className="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-600 focus:bg-white focus:ring-4 focus:ring-blue-100"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between">
                <label className="block text-sm font-semibold text-slate-700">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-xs font-medium text-blue-700 hover:text-blue-800"
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                className="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-blue-600 focus:bg-white focus:ring-4 focus:ring-blue-100"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {errorMessage && (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {errorMessage}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-blue-700 py-3.5 text-sm font-semibold text-white shadow-md transition hover:bg-blue-800 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {loading ? "Signing In..." : "Sign In to Office Portal"}
            </button>
          </form>

          <div className="mt-5 border-t border-slate-200 pt-4 text-center">
            <p className="text-xs text-slate-500">
              © 2026 B V C & Co., Chartered Accountants • Internal Use Only
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ title, text }: { title: string; text: string }) {
  return (
    <div className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur">
      <p className="text-sm font-bold">{title}</p>
      <p className="mt-1 text-xs leading-5 text-blue-100">{text}</p>
    </div>
  );
}
