-- STEP 1: Add role/access fields to employee_profiles
-- Run this once in Supabase SQL Editor before running the bulk user script.

ALTER TABLE employee_profiles
ADD COLUMN IF NOT EXISTS official_email TEXT,
ADD COLUMN IF NOT EXISTS designation TEXT,
ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'employee';

-- Recommended allowed values: article, employee, admin, partner
-- This check is optional; if it fails because old data has other roles, skip it for now.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'employee_profiles_role_check'
  ) THEN
    ALTER TABLE employee_profiles
    ADD CONSTRAINT employee_profiles_role_check
    CHECK (role IN ('article', 'employee', 'admin', 'partner'));
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS employee_profiles_user_id_unique
ON employee_profiles(user_id);

CREATE INDEX IF NOT EXISTS employee_profiles_role_idx
ON employee_profiles(role);
